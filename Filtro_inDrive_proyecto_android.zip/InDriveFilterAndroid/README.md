# Filtro inDrive — proyecto Android inicial

Este es un **prototipo de código fuente**, no un APK compilado ni una aplicación lista para producción.

## Objetivo
Aplicación auxiliar para Android que configura:
- dinero mínimo por kilómetro del viaje;
- distancia máxima hasta el punto de recogida.

Incluye un servicio de accesibilidad de desarrollo que lee el texto visible de la ventana activa y lo registra en Logcat. Todavía no interpreta de forma fiable las tarjetas de inDrive: la interfaz debe inspeccionarse en el teléfono y en la versión concreta de la app.

## Límites importantes de esta versión
- No acepta, rechaza, oculta ni pulsa solicitudes.
- No incluye aún botón flotante ni comandos de voz.
- No envía datos a servidores.
- El cálculo por km debe definirse claramente: tarifa / distancia del viaje. La distancia de recogida se evalúa aparte.
- Android y las condiciones de inDrive pueden limitar la automatización. No se debe intentar eludir controles de seguridad ni simular acciones no permitidas.

## Compilar
1. Instalar Android Studio actualizado.
2. Abrir la carpeta `InDriveFilterAndroid`.
3. Dejar que Gradle sincronice el proyecto.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración normalmente aparece en `app/build/outputs/apk/debug/app-debug.apk`.

## Pruebas necesarias
1. Probar primero en un teléfono secundario o con solicitudes de prueba.
2. Activar el servicio desde Ajustes > Accesibilidad > Servicios instalados > Lector de solicitudes.
3. Conectar Logcat en Android Studio y filtrar por `InDriveFilter`.
4. Revisar qué texto expone realmente la pantalla de inDrive. No se debe asumir que tarifa y distancias aparecen siempre en texto accesible.

## Compatibilidad
El proyecto apunta a Android 8.0 (API 26) o superior y compileSdk 35. La compatibilidad real debe probarse en distintos fabricantes y versiones.
