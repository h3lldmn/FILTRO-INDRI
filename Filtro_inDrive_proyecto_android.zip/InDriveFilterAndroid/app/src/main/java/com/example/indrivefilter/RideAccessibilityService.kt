package com.example.indrivefilter

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log

class RideAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val root = rootInActiveWindow ?: return
        val visibleText = StringBuilder()
        collectText(root, visibleText)
        // Registro de desarrollo: primero hay que verificar los textos reales de la interfaz
        // de inDrive en cada versión/país antes de crear un analizador fiable.
        Log.d("InDriveFilter", visibleText.toString().take(4000))
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder) {
        if (node == null) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let {
            out.append(it).append(" | ")
        }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let {
            out.append(it).append(" | ")
        }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out)
    }

    override fun onInterrupt() = Unit
}
