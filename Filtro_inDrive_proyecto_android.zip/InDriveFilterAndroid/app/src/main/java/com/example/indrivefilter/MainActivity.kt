package com.example.indrivefilter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("rules", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Filtro inDrive · Prototipo"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "Configura cuánto quieres ganar por kilómetro y qué tan lejos aceptas recoger."
            textSize = 15f
        })
        val minRate = EditText(this).apply {
            hint = "Dinero mínimo por km (ej. 0.50)"
            inputType = 8194
            setText(prefs.getString("min_rate", "0.50"))
        }
        val maxPickup = EditText(this).apply {
            hint = "Recogida máxima en km (ej. 3)"
            inputType = 8194
            setText(prefs.getString("max_pickup", "3.0"))
        }
        layout.addView(minRate)
        layout.addView(maxPickup)
        layout.addView(Button(this).apply {
            text = "Guardar parámetros"
            setOnClickListener {
                prefs.edit()
                    .putString("min_rate", minRate.text.toString())
                    .putString("max_pickup", maxPickup.text.toString())
                    .apply()
                text = "Guardado"
            }
        })
        layout.addView(Button(this).apply {
            text = "Activar lector de solicitudes"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nNota: esta versión inicial solo prepara la configuración y lectura autorizada de texto visible. No pulsa, acepta ni rechaza viajes automáticamente."
            textSize = 13f
        })
        setContentView(layout)
    }
}
