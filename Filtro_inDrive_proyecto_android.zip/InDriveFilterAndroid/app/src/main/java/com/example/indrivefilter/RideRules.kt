package com.example.indrivefilter

data class RideInfo(
    val fare: Double?,
    val tripKm: Double?,
    val pickupKm: Double?
)

data class RuleResult(
    val hasEnoughData: Boolean,
    val passesFarePerKm: Boolean,
    val passesPickupDistance: Boolean,
    val farePerKm: Double?
)

object RideRules {
    fun evaluate(ride: RideInfo, minMoneyPerKm: Double, maxPickupKm: Double): RuleResult {
        val ratio = if (ride.fare != null && ride.tripKm != null && ride.tripKm > 0.0)
            ride.fare / ride.tripKm else null
        val enough = ratio != null && ride.pickupKm != null
        return RuleResult(
            hasEnoughData = enough,
            passesFarePerKm = ratio != null && ratio >= minMoneyPerKm,
            passesPickupDistance = ride.pickupKm != null && ride.pickupKm <= maxPickupKm,
            farePerKm = ratio
        )
    }
}
